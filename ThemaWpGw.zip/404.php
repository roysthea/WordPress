<?php
/**
* The template for displaying 404 pages (not found).
*
* @link https://codex.wordpress.org/Creating_an_Error_404_Page
*
* @package Photo_Perfect
*/

get_header(); ?>
<div id="primary" class="content-area">
<main id="main" class="site-main" role="main">
<section class="error-404 not-found">
<header class="page-header">
<h2><?php esc_html_e( '404', 'photo-perfect' ); ?></h2>
<h1 class="page-title"><?php esc_html_e( 'Oops! Halaman tidak di temukan.', 'photo-perfect' ); ?></h1>
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
</header><!-- .page-header -->
<div class="page-content">
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<p><?php esc_html_e( 'Tidak di temukan, silahkan ketikan kata kunci yg lain?', 'photo-perfect' ); ?></p>
<?php get_search_form(); ?>
<?php
wp_nav_menu( array(
'theme_location' => 'notfound',
'depth'          => 1,
'fallback_cb'    => false,
'container'      => 'div',
'container_id'   => 'quick-links-404',
)
);
?>
</div><!-- .page-content -->
</section><!-- .error-404 -->
</main><!-- #main -->
</div><!-- #primary -->
<?php get_footer(); ?>


