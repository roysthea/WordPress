<?php
/**
* Template part for displaying posts in masonry.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package Photo_Perfect
*/

?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'masonry-entry' ); ?>>
<?php
$featured_image_full_url = '';
if ( has_post_thumbnail() ) {
$featured_image_full_url = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );
}
?>

<div class="masonry-thumbnail post-item">
<a href='https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1'>
<img src='https://www.truelancer.com/assets/images/tl-p2.png' alt='' />
</a>
<?php if ( has_post_thumbnail() ) :  ?>
<a href="<?php echo esc_url( $featured_image_full_url ); ?>" class="post-thumb popup-link">
<?php the_post_thumbnail( 'large' ); ?>
</a>
<?php else : ?>
<?php
$no_image_url = '';
$random_number = rand( 1, 2 );
$no_image_url = get_template_directory_uri() . '/images/no-image-'. esc_attr( $random_number ). '.png';
?>
<a href="<?php the_permalink(); ?>" class="post-thumb">
<img src="<?php echo esc_url( $no_image_url );?>" alt="<?php the_title_attribute(); ?>" />
</a>
<?php endif ?>
<div class="post-content">
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<?php if ( ! empty( $featured_image_full_url ) ) :  ?>
<a href="<?php echo esc_url( $featured_image_full_url ); ?>" class="popup-link"><i class="fa fa-eye"></i></a>
<?php endif ?>
Dicobaan hela
<a href="<?php the_permalink(); ?>"><i class="fa fa-link"></i></a>
<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
</div>
</div><!-- .masonry-thumbnail -->
</article><!-- #post-## -->




