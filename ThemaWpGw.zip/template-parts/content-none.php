<?php
/**
* Template part for displaying a message that posts cannot be found.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package Photo_Perfect
*/

?>
<section class="no-results not-found">
<header class="page-header">
<h1 class="page-title"><?php esc_html_e( 'Nothing Found', 'photo-perfect' ); ?></h1>
</header><!-- .page-header -->
<div class="page-content">
<?php if ( is_home() && current_user_can( 'publish_posts' ) ) : ?>
<p><?php printf( wp_kses( __( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'photo-perfect' ), array( 'a' => array( 'href' => array() ) ) ), esc_url( admin_url( 'post-new.php' ) ) ); ?></p>
<?php elseif ( is_search() ) : ?>
<p><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'photo-perfect' ); ?></p>
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<?php get_search_form(); ?>
<?php else : ?>
<p><?php esc_html_e( 'It seems we can’t find what you’re looking for. Perhaps searching can help.', 'photo-perfect' ); ?></p>
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<?php get_search_form(); ?>
<?php endif; ?>
</div><!-- .page-content -->
</section><!-- .no-results -->

