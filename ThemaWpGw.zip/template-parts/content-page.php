<?php
/**
* Template part for displaying page content in page.php.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package Photo_Perfect
*/

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<div class="entry-content">
<?php
/**
* Hook - photo_perfect_single_image.
*
* @hooked photo_perfect_add_image_in_single_display -  10
*/
do_action( 'photo_perfect_single_image' );
?>
<?php the_content(); ?>
<a href='https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1'>
<img src='https://www.truelancer.com/assets/images/tl-p1.png' alt='' />
</a>
<?php
wp_link_pages( array(
'before'      => '<div class="page-links"><span>' . esc_html__( 'Pages:', 'photo-perfect' ) . '</span>',
'after'       => '</div>',
'link_before' => '<span>',
'link_after'  => '</span>',
) );
?>
</div><!-- .entry-content -->
<footer class="entry-footer">
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<?php edit_post_link( esc_html__( 'Edit', 'photo-perfect' ), '<span class="edit-link">', '</span>' ); ?>
</footer><!-- .entry-footer -->
</article><!-- #post-## -->



