<?php
/**
* Template part for displaying single posts.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package Photo_Perfect
*/

?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
<a href="https://jetpack.com/pricing/?aff=9837"> <img src="http://refer.wordpress.com/wp-content/uploads/2018/02/large-leaderboard- alt2.png"></a>
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<div class="entry-content">
<a href="https://publishers.propellerads.com/#/pub/auth/signUp?refId=Tofd"><img src="http://promo.propellerads.com/728x90_02.jpg" alt="PropellerAds"></a>
<?php
/**
* Hook - photo_perfect_single_image hook.
*
* @hooked photo_perfect_add_image_in_single_display -  10
*/
do_action( 'photo_perfect_single_image' );
?>
<?php the_content(); ?>
<a href='https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1'>
<img src='https://www.truelancer.com/assets/images/tl-p1.png' alt='' />
</a></
a href="https://publishers.propellerads.com/#/pub/auth/signUp?refId=Tofd"><img src="http://promo.propellerads.com/728x90-propellerads-monetize-traffic.gif" alt="PropellerAds"></a>
<?php
wp_link_pages( array(
'before'      => '<div class="page-links"><span>' . esc_html__( 'Pages:', 'photo-perfect' ) . '</span>',
'after'       => '</div>',
'link_before' => '<span>',
'link_after'  => '</span>',
) );
?>
<a href='https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1'>
<img src='https://www.truelancer.com/assets/images/tl-p2.png' alt='' />
</a>
</div><!-- .entry-content -->
<footer class="entry-footer">
<?php photo_perfect_entry_footer(); ?>
</footer><!-- .entry-footer -->
</article><!-- #post-## -->




















