<?php
/**
* Template part for displaying posts.
*
* @link https://codex.wordpress.org/Template_Hierarchy
*
* @package Photo_Perfect
*/

?>
<?php
global $photo_perfect_post_count;
$odd_or_even = ( 0 === $photo_perfect_post_count % 2 ) ? 'even' : 'odd' ;
// Increase count.
$photo_perfect_post_count++;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class( 'archive-post-' . $odd_or_even ); ?>>
<?php if ( has_post_thumbnail() && 'odd' === $odd_or_even ) :  ?>
<div class="thumb-archive">
<center>
<a href='https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1'><img src='https://www.truelancer.com/assets/images/tl-p1.png' alt='' />
</a>
</center>
<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a>
</div>
<?php endif ?>
<div class="archive-content">
<header class="entry-header">
<?php if ( 'post' === get_post_type() ) : ?>
<?php photo_perfect_show_post_categories(); ?>
<?php endif; ?>
<?php the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>
<script>
image = new Array('<a href="https://poin-web.co.id/invitation/163531"><marquee>Dapat kan 2500 poin, untuk kamu yg suka ikut survey</marquee></a>','<a href="https://tokopedia.link/TPROY5127"><marquee>Saldo 10000 buat kamu, buka untuk belanja</marquee></a>','<a href="http://www.bukalapak.com/rf/shobry_net1vab"><marquee>Yuk belanja dibukalapak, dapatkan saldo 10 ribu</marquee></a>');
n=Math.floor(Math.random() * 3);
document.write(image[n]);
</script>
<?php if ( 'post' === get_post_type() ) : ?>
<div class="entry-meta">
<?php photo_perfect_posted_on(); ?>
</div><!-- .entry-meta -->
<?php endif; ?>
</header>
<div class="entry-content">
<?php the_excerpt(); ?>
</div>
</div>
<?php if ( has_post_thumbnail() && 'even' === $odd_or_even ) :  ?>
<div class="thumb-archive">
<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'large' ); ?></a>
<a href="https://www.truelancer.com/?utm_source=affiliate&utm_medium=affiliate&utm_campaign=TL_Affiliate&aid=MTU0Nl8xMzQ1">
<img src="https://www.truelancer.com/assets/images/tl-p1.png"/>
</a>><
/div>
<?php endif ?>
</article><!-- #post-## -->




